package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class login {

	public WebDriver Idriver;
	public login(WebDriver rdriver) {
		Idriver=rdriver;
		PageFactory.initElements(rdriver,this);
	}
	
	@FindBy(id="user-name")
	@CacheLookup
	WebElement txtuserName;
	
	@FindBy(id="password")
	@CacheLookup
	WebElement txtpassword;
	
	@FindBy(id="login-button")
	@CacheLookup
	WebElement btnLogin;
	
	@FindBy(xpath="//span[contains(text(),'Products')]")
	@CacheLookup
	WebElement titleproduct;
	
	@FindBy(xpath="//button[contains(text(),'Add to cart')][1]")
	@CacheLookup
	WebElement FirstAddtocart;
	
	@FindBy(xpath="//a[@class='shopping_cart_link']")
	@CacheLookup
	WebElement shoppingCart;
	
	@FindBy(name="checkout")
	@CacheLookup
	WebElement btnCheckOut;
	
	@FindBy(name="firstName")
	@CacheLookup
	WebElement txtFirstName;
	@FindBy(name="lastName")
	@CacheLookup
	WebElement txtLastName;
	@FindBy(name="postalCode")
	@CacheLookup
	WebElement txtPostalCode;
	@FindBy(name="continue")
	@CacheLookup
	WebElement btnContinue;
	
	@FindBy(name="finish")
	@CacheLookup
	WebElement btnFinish;
	
	
	
	public void setuserName(String userName) {
		txtuserName.clear();
		txtuserName.sendKeys(userName);
	}
	
	
	public void setPassword(String passWord) {
		txtpassword.clear();
		txtpassword.sendKeys(passWord);
	}
	
	public void clickLogin() {
		
		btnLogin.click();
	}
	
	public void AddtoCart() {
		FirstAddtocart.click();
		
	}
	public void clickShoppingCart() {
		shoppingCart.click();
		
	}
	public void clickCheckout() {
		btnCheckOut.click();
		
	}
	public void enterFirstName(String fname) {
		txtFirstName.clear();
		txtFirstName.sendKeys(fname);
		
	}
	
	public void enterLastName(String lname) {
		txtLastName.clear();
		txtLastName.sendKeys(lname);
		
	}
	public void enterZipCode(String zip) {
		txtPostalCode.clear();
		txtPostalCode.sendKeys(zip);
		
	}
	public void clickContinue() {
		btnContinue.click();
		
	}
	public void clickFinish() {
		btnFinish.click();
		
	}
	
}
