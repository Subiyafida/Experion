package steps;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.login;

public class loginsteps {
	public WebDriver driver;
	public login objLogin;
	
	
	@Given("User has opened Swag Labs on the browser")
	public void user_has_opened_swag_labs_on_the_browser() {
		
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"/Driver/chromedriver.exe");
		driver=new ChromeDriver();
		objLogin=new login(driver);
		
	
	}

	@Given("User has navigated to Swag Labs URL")
	public void user_has_navigated_to_swag_labs_url() throws InterruptedException {
		driver.get("https://www.saucedemo.com/");
		Thread.sleep(2000);
	  	}

	@When("User enter valid {string} and {string}")
	public void user_enter_valid_standard_user_and_secret_sauce(String username, String password) {
		objLogin.setuserName(username);
		objLogin.setPassword(password);
	}

	@When("User click the login button on valid case")
	public void user_click_the_login_button_on_valid_case() {
		objLogin.clickLogin();
	}

	@Then("Showing Swag Labs title at the top of the page")
	public void showing_swag_labs_title_at_the_top_of_the_page() {
	   if(driver.getPageSource().contains("sorry")) {
		   driver.close();
		   Assert.assertTrue(false);
	   }
	   else {
		   Assert.assertEquals("Swag Labs",driver.getTitle());
	   }
	}

	@Then("close the page")
	public void close_the_page() {
		driver.quit();
	}
	
	@Then("Verify products list page displayed to the user successfully")
	public void verify_product_list() {
		Assert.assertTrue(driver.getPageSource().contains("Products"));
	}
	
	@And("Add product to cart")
	public void add_product_to_cart() throws InterruptedException {
		Thread.sleep(2000);
		objLogin.AddtoCart();
		Thread.sleep(2000);
	}
	
	

	@Then("Click on shopping cart button on the top of the page")
	public void click_on_shopping_cart_button_on_the_top_of_the_page() throws InterruptedException {
		Thread.sleep(2000);
		objLogin.clickShoppingCart();
		Thread.sleep(2000);
	    
	}
	@Then("verify your cart page is displayed")
	public void verify_your_cart_page_is_displayed() {
		Assert.assertTrue(driver.getPageSource().contains("Your Cart"));
	    
	}
	@Then("click on checkout button")
	public void click_on_checkout_button() throws InterruptedException {
		Thread.sleep(2000);
		objLogin.clickCheckout();
		Thread.sleep(2000);
	    
	   
	}
	@Then("Enter First name {string}")
	public void enter_first_name(String fname) {
		objLogin.enterFirstName(fname);
		
	    
	}
	@Then("Enter Last name {string}")
	public void enter_last_name(String lname) {
		objLogin.enterLastName(lname);
	  
	}
	@Then("Enter zip code {string}")
	public void enter_zip_code(String zip) {
		objLogin.enterZipCode(zip);
	 
	}
	@Then("click on continue button")
	public void click_on_continue_button() throws InterruptedException {
		Thread.sleep(2000);
		objLogin.clickContinue();
		Thread.sleep(2000);
	    
	}
	@Then("verify Checkout: Overview page displayed")
	public void verify_checkout_overview_page_displayed() {
		Assert.assertTrue(driver.getPageSource().contains("Checkout: Overview"));
	    
	 
	}
	@Then("click on Finish button")
	public void click_on_finish_button() throws InterruptedException {
		Thread.sleep(2000);
		objLogin.clickFinish();
		Thread.sleep(2000);
		
	}
	@And("verify order palced successfully")
	public void verify_success_order() {
		Assert.assertTrue(driver.getPageSource().contains("Thank you for your order"));
	    
	}
	




}
